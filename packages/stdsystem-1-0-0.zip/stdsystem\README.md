# stdsystem

Camada de sistema para IO, processo, tempo, memoria e utilidades do Windows.

Imports comuns:

import "stdsystem/io.abj";
import "stdsystem/process.abj";
import "stdsystem/memory.abj";