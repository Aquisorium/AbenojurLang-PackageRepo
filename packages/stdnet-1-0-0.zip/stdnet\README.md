# stdnet

Camada de rede com HTTP, webserver, websocket e Harbor.

Imports comuns:

import "stdnet/http.abj";
import "stdnet/webserver.abj";
import "stdnet/harbor.abj";