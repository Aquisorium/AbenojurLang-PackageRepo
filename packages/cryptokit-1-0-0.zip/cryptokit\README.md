# cryptokit

Helpers de hash, UUID e aleatoriedade da stdlib do Abenojur.

Importe com:

import "cryptokit/crypto.abj";