# stdcore

Core e prelude principal do ecossistema Abenojur.

Importe com:

import "stdcore/prelude.abj";