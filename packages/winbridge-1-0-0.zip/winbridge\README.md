# winbridge

Bindings de WinAPI e FFI para projetos Abenojur no Windows.

Imports comuns:

import "winbridge/winapi.abj";
import "winbridge/cffi.abj";